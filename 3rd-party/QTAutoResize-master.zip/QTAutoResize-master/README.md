# AutoResize
QT AutoResize is a code to make your qtwidget autoresize by your parent size changing
# How to use
you can make a object of the class AutoResize in you widget.
And, call the function doAutoResize in your widget resizeEvent function
